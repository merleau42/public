#include <bits/stdc++.h>

using namespace std;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int X{};
	cin >> X;
	cout << __builtin_popcount(X) << "\n";
	return 0;
}

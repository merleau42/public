#include <bits/stdc++.h>

using namespace std;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int a{}, b{};
	cin >> a >> b;
	cout << fixed << setprecision(10);
	cout << a * 1.0 / b << "\n";
	return 0;
}

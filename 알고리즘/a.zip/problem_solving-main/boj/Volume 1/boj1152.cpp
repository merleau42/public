#include <bits/stdc++.h>

using namespace std;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	string s;
	int ans{};
	while (cin >> s) {
		++ans;
	}
	cout << ans << "\n";
	return 0;
}

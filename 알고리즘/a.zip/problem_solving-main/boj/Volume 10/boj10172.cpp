#include <bits/stdc++.h>

using namespace std;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout << "|\\_/|\n";
	cout << "|q p|   /}\n";
	cout << "( 0 )\"\"\"\\\n";
	cout << "|\"^\"`    |\n";
	cout << "||_/=\\\\__|\n";
	return 0;
}

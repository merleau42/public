#include <bits/stdc++.h>

using namespace std;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout << "\\    /\\\n";
	cout << " )  ( ')\n";
	cout << "(  /  )\n";
	cout << " \\(__)|\n";
	return 0;
}
